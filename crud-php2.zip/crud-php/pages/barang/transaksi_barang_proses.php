<?php
include "../../conf/conn.php";

if ($_POST) {
    $id = $_POST['id'];
    $harga = $_POST['harga'];
    $jumlah = $_POST['jumlah'];
    $total = $harga * $jumlah;

    $query = "INSERT INTO penjualan (id_barang, harga, qty, total) VALUES ('$id', '$harga', '$jumlah', '$total')";
    
    // Eksekusi query
    $result = mysqli_query($koneksi, $query);

    if (!$result) {
        // Tangani kesalahan query
        die("Error: " . mysqli_error($koneksi));
    } else {
        echo '<script>alert("Data Berhasil Ditambahkan !!!");
        window.location.href="../../index.php?page=data_barang"</script>';
    }
}
?>
